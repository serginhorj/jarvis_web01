# Cyborgue Web — SPEC

## 1. Objetivo

Assistente pessoal web inspirada no J.A.R.V.I.S. com voz (PT-BR), painéis
flutuantes, gestos e integração futura com o PC e com o Home Assistant.
**Referências intocadas:** `D:\Jarvis_v3\Mark-LVI-main` (projeto de origem) e
`D:\meu_agente_metal\Agente_Ultron` (evolução local em uso).

## 2. Arquitetura

```
Chrome (frontend)                 Backend (FastAPI)            Serviços externos
──────────────────                     ───────────              ────────────────
static/index.html ── WebSocket /ws ──► jarvis/backend/main.py ─► Gemini Live API
js/app.js   (orquestração)             ├─ memória JSON data/     (áudio bidi + tools)
js/audio.js (mic PCM16@16k, fila 24k)  ├─ ferramentas servidor    (time_now, memory_*   )
js/core.js  (anéis reativos)           ├─ ferramentas de UI      (ui_open_panel etc.)
js/panels.js (painéis/toasts)          ├─ /healthz               ─► Home Assistant (Fase 7)
js/pcm-worklet.js (coleta ~64ms)       └─ token APP_TOKEN no WS  ─► Agente desktop (Fase 6)
```

### Protocolo do WebSocket (implementado)

| Direção | Formato | Conteúdo |
|---|---|---|
| cliente→servidor | binário | PCM16 mono 16 kHz (bloco ~64 ms) |
| cliente→servidor | JSON | `{"type":"text","text":…}` · `{"type":"interrupt"}` |
| servidor→cliente | binário | PCM16 mono 24 kHz (resposta falada) |
| servidor→cliente | JSON | `ready` · `transcript` (user/jarvis) · `interrupted` · `turn_complete` · `tool_call` · `tool_used` · `error` |

Autenticação: `ws://host/ws?token=APP_TOKEN`. Sem/baixo token → recusa
(HTTP 403 no handshake; código 4401 quando possível).

## 3. Estado por fase

| Fase | Escopo | Estado |
|---|---|---|
| 1 | Análise | ✅ concluída (diagnóstico apresentado) |
| 2 | Interface web | ✅ concluída e testada (Chrome headless, console limpo) |
| 3 | Voz/Gemini | ⏳ backend existente; falta `.env` real e testes de áudio |
| 4 | Ferramentas | ⏳ existem no backend; testes ponta a ponta pendentes |
| 5 | Gestos (MediaPipe) | ⏳ não iniciado (botão da câmera desativado) |
| 6 | PC via agente desktop | ⏳ não iniciado |
| 7 | Home Assistant (tomada Tuya) | ⏳ não iniciado |
| 8 | VPS/HTTPS | ⏳ não iniciado (requer VPS confirmada) |

## 4. Decisões técnicas

- **Sem Vite por enquanto**: o backend já serve `static/` — evita cadeia de
  ferramentas Node para o usuário. Migração para Vite é possível depois sem
  mudar o backend.
- **Frontend vanilla ES modules**: sem dependências de build, consiste com o
  nível do projeto e facilita a depuração.
- **AudioWorklet próprio** (`pcm-worklet.js`): coleta Float32 e o app converte
  para PCM16; re-amostragem linear é o fallback se o AudioContext não ficar a
  16 kHz (Chrome honra a taxa pedida).
- **Barge-in best-effort**: nível RMS local alto durante a fala → `interrupt`
  (limitado por cooldown). A detecção fina vem com os gestos/transcrição (Fase 5+).
- **Nomes não inventados**: o fallback do backend `GEMINI_MODEL=gemini-3.8-live`
  precisa ser validado na documentação oficial da Live API antes da Fase 3.

## 5. Segurança

- Credenciais só no backend (`.env`, fora do git):
  `GEMINI_API_KEY`, `GEMINI_MODEL`, `GEMINI_VOICE`, `APP_TOKEN`, `USER_NAME`,
  `HOME_ASSISTANT_URL`, `HOME_ASSISTANT_TOKEN`, `MEM0_API_KEY`.
- Página nunca vê chaves; somente o documento `/healthz` sem sigilo (status).
- Token exigido no WS; reconexão com recuo progressivo (máx. 5 tentativas).
- Ações sensíveis (Fases 6/7) exigirão confirmação na interface.
