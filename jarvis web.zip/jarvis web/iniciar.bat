@echo off
title Cyborgue Web
cd /d "%~dp0"
python iniciar_cyborgue.py
pause
