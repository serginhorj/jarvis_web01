"""Inicia a Cyborgue Web carregando o .env desta pasta (sem alterar o backend).

Uso:  python iniciar_cyborgue.py
"""
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BACKEND = ROOT / "jarvis" / "backend"

# 1. Carrega o .env (sem sobrescrever variáveis já definidas)
env_file = ROOT / ".env"
if env_file.exists():
    for line in env_file.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            key, _, value = line.partition("=")
            key = key.strip()
            if key and key not in os.environ:
                os.environ[key] = value.strip()
else:
    print("AVISO: .env não encontrado — copie .env.example para .env e preencha.")

# 2. Garante que o backend tem os caminhos certos
os.environ.setdefault("STATIC_DIR", str(BACKEND / "static"))
os.environ.setdefault("DATA_DIR", str(BACKEND / "data"))

# 3. Sobe o servidor
sys.path.insert(0, str(BACKEND))

import uvicorn  # noqa: E402

if __name__ == "__main__":
    if not os.environ.get("GEMINI_API_KEY"):
        print("AVISO: GEMINI_API_KEY ausente — a página abrirá em modo de conexão com erro de modelo.")
    port = int(os.environ.get("PORT", "8000"))
    print(f"Cyborgue Web em http://127.0.0.1:{port}/  (Ctrl+C para encerrar)")
    uvicorn.run("main:app", host="127.0.0.1", port=port, log_level="info")
