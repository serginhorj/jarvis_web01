# Cyborgue Web — README

Versão web da assistente pessoal **Cyborgue** (estilo J.A.R.V.I.S.), com voz via
Gemini Live API. Este projeto **não substitui** o agente desktop — ele coexiste
com ele.

## O que já funciona (Fase 2 concluída)

- ✅ Interface HUD futurista (tema escuro, ciano/azul, vidro, tipografia Orbitron)
- ✅ Página servida pelo próprio backend em `http://127.0.0.1:8000/`
- ✅ Conexão WebSocket `/ws` com token de acesso
- ✅ Painéis flutuantes arrastáveis (mouse **e** toque)
- ✅ Reprodução de áudio do microfone via AudioWorklet (estrutura pronta, testes na Fase 3)
- ✅ Status claro: SEM CONEXÃO (demo) → OUVINDO → FALANDO → ERRO

## O que ainda NÃO funciona (fases futuras)

| Recurso | Fase |
|---|---|
| Voz real com Gemini (sem `.env` configurado) | 3 |
| Ferramentas: hora/memória/painéis end-to-end | 4 |
| Gestos com webcam (botão "GESTOS · FASE 5" está desativado) | 5 |
| Integração PC (agente desktop) | 6 |
| Home Assistant / tomada | 7 |
| VPS/HTTPS | 8 |

## Instalação (Windows 10 + VS Code)

1. Abra o terminal do VS Code na pasta `jarvis web`.
2. Verifique as dependências Python (Python 3.11 já funciona):

   ```
   pip install -r jarvis\backend\requirements.txt
   ```

3. Crie o arquivo `.env` na pasta `jarvis web` **a partir do `.env.example`** e
   preencha com SUA chave real do Gemini (Google AI Studio) e um token
   qualquer que você inventar (ex.: um segredo longo, usado pela página para
   entrar). Nunca compartilhe o `.env`.

## Como iniciar

Opção 1 — script pronto (carrega o `.env` automaticamente, sem tocar no código):

```
iniciar.bat
```

Opção 2 — manual, dentro de `jarvis\backend`:

```
python -m uvicorn main:app --host 127.0.0.1 --port 8000
```

Depois abra no Chrome: **http://127.0.0.1:8000/**

- A página pedirá o **endereço do backend** (padrão `http://127.0.0.1:8000`)
  e o **token** (o mesmo `APP_TOKEN` do `.env`).
- Se aparecer "DEMONSTRAÇÃO", a Cyborgue está sem conexão — mas a interface
  funciona e as transcrições não são enviadas.
- Se der "erro 10048" (porta em uso), feche o console antigo do servidor ou
  mude a porta com `PORT` no `.env` / no comando.

## Estrutura

```
jarvis web/
├── jarvis/backend/          ← backend FastAPI (existente, núcleo mantido)
│   ├── main.py              ← ponte WS ↔ Gemini Live (Fases 3 e 4)
│   └── static/              ← frontend da Fase 2
│       ├── index.html
│       ├── css/style.css
│       └── js/ app.js, audio.js, core.js, panels.js, pcm-worklet.js
├── .env.example             ← modelo de variáveis (sem credenciais)
├── .gitignore
├── iniciar_cyborgue.py      ← carrega .env e sobe o servidor
├── iniciar.bat
├── README.md                ← este arquivo
└── SPEC.md                  ← arquitetura e plano de fases
```

## Segurança

- Chaves ficam **só no backend** (`.env`, fora do git).
- O navegador só recebe/envia áudio e texto; a chave do Gemini nunca chega à página.
- Acesso do WebSocket exige o `APP_TOKEN`.
