Crie do zero um assistente pessoal estilo J.A.R.V.I.S. (Homem de Ferro) e deixe-o no ar em https://jarvis2.trecofantastico.com.br. Trabalhe de forma autônoma, teste cada etapa e só diga "pronto" quando a URL estiver respondendo.

## Contexto
- VPS Ubuntu vazia, acesso root. O domínio já aponta para o IP da VPS.
- A VPS não tem câmera, microfone nem tela: tudo sensorial roda no navegador do usuário. A VPS só serve a página e faz a ponte com a IA. A chave de API nunca pode ir para o navegador.
- Chave Gemini (Google AI Studio, plano gratuito): AQ.Ab8RN6KGRWYEXyzIqC7WpgGN8odFk89rkfAIpKaWVx_9lb66CA
- Nome do usuário: Raphael.

## Infraestrutura (obrigatório, a VPS está vazia)
1. Instalar Docker e iniciar Docker Swarm (`docker swarm init`).
2. Criar a rede overlay `network_public`.
3. Subir o Traefik v2 como stack no Swarm: entrypoints 80 e 443, redirect HTTP→HTTPS, certresolver Let's Encrypt (`letsencryptresolver`, challenge TLS ou HTTP), provider Docker Swarm, volume para o `acme.json`.
4. O app sobe como stack separada (`docker stack deploy`), 1 réplica, imagem construída localmente, com labels Traefik: Host(`jarvis2.trecofantastico.com.br`), entrypoint websecure, certresolver, porta interna 8000. WebSocket precisa passar pelo Traefik.
5. Variáveis no `.env` (nunca commitar): GEMINI_API_KEY, GEMINI_MODEL, GEMINI_VOICE, APP_TOKEN, USER_NAME.
6. Script `deploy.sh` que faz build, deploy e força atualização do serviço (`docker service update --force`), já que a tag é `latest`.

## Aplicação
**Backend (Python 3.12, FastAPI, SDK `google-genai`)**
- Endpoint `/ws`: WebSocket único com o navegador. Áudio do mic chega como binário PCM16 16 kHz; áudio da resposta volta como binário PCM16 24 kHz; o resto é JSON (`transcript`, `tool_call`, `turn_complete`, `interrupted`, `error`, `ready`).
- Ponte com a **Gemini Live API** (`client.aio.live.connect`), modelo `gemini-3.8-live` (ou o mais recente com `bidiGenerateContent` disponível na chave), `response_modalities=["AUDIO"]`, voz `Charon`, `language_code="pt-BR"`, transcrição de entrada e saída ativadas, VAD automático. Atenção: `session.receive()` termina a cada `turn_complete`, precisa de loop externo `while True`.
- Não usar Google Search grounding: no plano gratuito dá erro de cota na Live API. Deixar atrás de uma flag `GEMINI_SEARCH=0`.
- Persona no system prompt: Jarvis, português do Brasil, calmo, levemente irônico, respostas curtas, chama o usuário de "senhor".
- Function calling: `time_now`, `memory_remember` / `memory_recall` (JSON em volume `/data`), `ui_open_panel(title, content)`, `ui_close_panels`, `ui_show_text(text)`. As `ui_*` são encaminhadas ao navegador.
- Auth: query `?token=` comparada com `APP_TOKEN`; rejeitar se diferente. Endpoint `/healthz`. Servir o frontend estático na raiz.

**Frontend (Vite + TypeScript, sem framework)**
- HUD escuro estilo Stark: orbe central que pulsa quando fala, log de transcrição, campo de texto para digitar, botões ATIVAR, mic e câmera.
- Mic: `getUserMedia` + AudioWorklet convertendo Float32 em PCM16 a 16 kHz. Player: fila de `AudioBufferSource` a 24 kHz com `flush()` ao receber `interrupted`.
- Gestos: `@mediapipe/tasks-vision` (GestureRecognizer, modo VIDEO, 1 mão) rodando no navegador. Cursor virtual segue o dedo indicador com suavização exponencial e x espelhado. Pinça (polegar+indicador) agarra e arrasta painéis; punho fechado sobre painel fecha; "V" liga/desliga mic; joinha confirma. Desenhar o esqueleto da mão num canvas sobre o vídeo da webcam.
- Painéis arrastáveis também por mouse. Token salvo em localStorage; se faltar, pedir via prompt. Erros (token inválido, mic bloqueado, cota do Gemini) em destaque no centro da tela.

**Docker**: Dockerfile multi-stage (node:22-alpine builda o frontend, python:3.12-slim roda uvicorn com o `dist` copiado), healthcheck em `/healthz`.

## Critérios de aceite
- `https://jarvis2.trecofantastico.com.br/healthz` retorna 200 com certificado Let's Encrypt válido.
- Teste automatizado via WebSocket pela URL pública: enviar texto "que horas são e abra um painel chamado Teste" e receber `tool_call` + áudio + transcrição, primeiro áudio em menos de 2 s.
- Página carrega no Chrome sem erros de console; ATIVAR conecta, pede microfone e o status mostra "online".
- Entregar `README.md` com como usar e operar, e `SPEC.md` com a arquitetura.