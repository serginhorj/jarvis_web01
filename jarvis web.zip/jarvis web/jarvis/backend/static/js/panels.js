/**
 * Painéis flutuantes arrastáveis + avisos (toasts).
 * Suporta mouse e toque via Pointer Events (gestos chegam na Fase 5).
 */

const container = () => document.getElementById("panels");

let zTop = 10;

/** Fecha todos os painéis abertos (ferramenta ui_close_panels). */
export function closeAllPanels() {
  for (const p of [...container().children]) p.remove();
}

/** Abre (ou atualiza) um painel com título e conteúdo. */
export function openPanel(title, content, { x = null, y = null } = {}) {
  // Se já existe painel com o mesmo título, só atualiza o conteúdo.
  for (const p of container().children) {
    if (p.dataset.title === title) {
      p.querySelector(".panel-body").textContent = content;
      return p;
    }
  }

  const el = document.createElement("div");
  el.className = "panel";
  el.dataset.title = title;
  el.innerHTML = `
    <div class="panel-head">
      <span>${escapeHtml(title)}</span>
      <button class="icon-btn" title="Fechar painel">✕</button>
    </div>
    <div class="panel-body"></div>`;
  el.querySelector(".panel-body").textContent = content;
  el.querySelector(".panel-head .icon-btn")
    .addEventListener("click", () => el.remove());

  // Posição inicial: em cascata sobre o palco.
  const st = document.querySelector(".stage").getBoundingClientRect();
  const n = container().children.length;
  x = x ?? st.left + 60 + n * 28;
  y = y ?? st.top + 90 + n * 28;
  el.style.left = `${clamp(x, 8, st.right - 220)}px`;
  el.style.top = `${clamp(y, 8, st.bottom - 120)}px`;
  el.style.zIndex = ++zTop;

  container().appendChild(el);
  makeDraggable(el, el.querySelector(".panel-head"), () => {
    el.style.zIndex = ++zTop;
  });
  return el;
}

/** Texto em destaque no HUD (ferramenta ui_show_text). */
export function showHudText(text) {
  const el = document.getElementById("hud-text");
  el.textContent = text;
  el.hidden = false;
  clearTimeout(showHudText._t);
  showHudText._t = setTimeout(() => { el.hidden = true; }, 8000);
}

/** Aviso temporário no topo da tela. */
export function toast(text, kind = "", ms = 4200) {
  const el = document.createElement("div");
  el.className = `toast ${kind ? `toast--${kind}` : ""}`.trim();
  el.textContent = text;
  document.getElementById("toasts").appendChild(el);
  setTimeout(() => el.remove(), ms);
}

/** Torna um elemento arrastável pelo cabeçalho (mouse + toque). */
function makeDraggable(el, handle, onGrab) {
  handle.addEventListener("pointerdown", (ev) => {
    if (ev.target.closest("button")) return; // não arrastar pelo botão fechar
    ev.preventDefault();
    const rect = el.getBoundingClientRect();
    const dx = ev.clientX - rect.left;
    const dy = ev.clientY - rect.top;
    handle.setPointerCapture(ev.pointerId);
    onGrab && onGrab();

    const move = (e) => {
      el.style.left = `${clamp(e.clientX - dx, 8, innerWidth - 220)}px`;
      el.style.top = `${clamp(e.clientY - dy, 8, innerHeight - 60)}px`;
    };
    const up = () => {
      handle.removeEventListener("pointermove", move);
      handle.removeEventListener("pointerup", up);
    };
    handle.addEventListener("pointermove", move);
    handle.addEventListener("pointerup", up);
  });
}

function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }

function escapeHtml(s) {
  return s.replace(/[&<>"']/g, (c) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
  }[c]));
}
