/**
 * CYBORGUE WEB — orquestrador
 * Conecta ao backend (WS /ws), liga o microfone, reproduz a resposta,
 * exibe transcrições e executa os painéis pedidos pelas ferramentas.
 *
 * Protocolo (implementado em backend/main.py):
 *   cliente → servidor: binário PCM16 16 kHz | {type:"text"} | {type:"interrupt"}
 *   servidor → cliente: {ready|transcript|interrupted|turn_complete|
 *                        tool_call|tool_used|error} | binário PCM16 24 kHz
 */

import { Microphone, Player } from "./audio.js";
import { closeAllPanels, openPanel, showHudText, toast } from "./panels.js";
import { createCore } from "./core.js";

const $ = (id) => document.getElementById(id);
const LS_TOKEN = "cyborgue_token";
const LS_ENDPOINT = "cyborgue_endpoint";

/* ---------- estado ---------- */
const S = {
  ws: null,
  mic: null,
  micOn: false,
  player: new Player(),
  core: createCore($("core")),
  status: "demo",
  reconnects: 0,
  lastWSURL: null,
};

const STATUS_LABEL = {
  demo: "DEMONSTRAÇÃO", off: "DESLIGADA", conn: "CONECTANDO",
  ready: "ONLINE", listen: "OUVINDO", speak: "FALANDO", error: "ERRO",
};

function setStatus(kind) {
  S.status = kind;
  const el = $("status");
  el.className = `status status--${kind}`;
  el.textContent = STATUS_LABEL[kind];
}

/* ---------- conversa ---------- */
function addMsg(role, text, cls = "") {
  const div = document.createElement("div");
  div.className = `msg msg--${role}${cls ? " " + cls : ""}`;
  div.textContent = text;
  const log = $("chat-log");
  log.appendChild(div);
  log.scrollTop = log.scrollHeight;
  return div;
}

let subtitleTimer = null;
function setSubtitle(text, sticky = false) {
  $("subtitles").textContent = text;
  clearTimeout(subtitleTimer);
  if (!sticky && text) {
    subtitleTimer = setTimeout(() => { $("subtitles").textContent = ""; }, 6000);
  }
}

/* ---------- conexão ---------- */
function backendEndpoint() {
  return localStorage.getItem(LS_ENDPOINT) || location.origin;
}

function wsURL() {
  const base = backendEndpoint()
    .replace(/^http/, "ws")
    .replace(/\/+$/, "");
  const token = localStorage.getItem(LS_TOKEN) || "";
  return `${base}/ws?token=${encodeURIComponent(token)}`;
}

function connect() {
  if (S.ws) { try { S.ws.close(); } catch {} S.ws = null; }

  const token = localStorage.getItem(LS_TOKEN);
  if (!token) {
    openConfig();
    return;
  }

  S.lastWSURL = wsURL();
  setStatus("conn");
  const ws = new WebSocket(S.lastWSURL);
  ws.binaryType = "arraybuffer";
  S.ws = ws;

  ws.onopen = () => { S.reconnects = 0; };

  ws.onmessage = (ev) => {
    if (ev.data instanceof ArrayBuffer) {   // áudio da resposta (24 kHz)
      S.player.enqueue(ev.data);
      if (S.status === "listen") { /* fala chegando */ }
      if (S.status !== "speak") setStatus("speak");
      S.core.speakPulse();
      return;
    }
    let env;
    try { env = JSON.parse(ev.data); } catch { return; }
    handleServer(env);
  };

  ws.onclose = (ev) => {
    S.ws = null;
    if (ev.code === 4401) {
      setStatus("demo");
      toast("Token inválido ou ausente no backend.", "err");
      openConfig();
      return;
    }
    if (S.reconnects < 5) {
      S.reconnects++;
      setStatus("conn");
      setTimeout(connect, 1500 * S.reconnects);
    } else {
      setStatus("error");
      toast("Sem conexão com o backend (host: " + backendEndpoint() + ")", "err", 6000);
      openConfig();
    }
  };

  ws.onerror = () => { /* onclose cuidará do estado */ };
}

function handleServer(env) {
  switch (env.type) {
    case "ready":
      setStatus("ready");
      S.reconnects = 0;
      $("btn-mic").disabled = false;
      addMsg("sys", `Conectada · modelo ${env.model} · voz ${env.voice}`);
      break;

    case "transcript": {
      const role = env.role === "user" ? "user" : "jarvis";
      addMsg(role, env.text);
      setSubtitle(`${role === "user" ? "Você: " : "Cyborgue: "}${env.text}`);
      break;
    }

    case "interrupted":
      S.player.abort();
      break;

    case "turn_complete":
      setStatus(S.micOn ? "listen" : "ready");
      break;

    case "tool_call":
      runUITool(env.name, env.args || {});
      break;

    case "tool_used": /* informativo */ break;

    case "error":
      addMsg("sys", env.message, "msg--err");
      toast(env.message, "err");
      break;
  }
}

/* ---------- ferramentas de interface (agendadas pelo backend) ---------- */
function runUITool(name, args) {
  switch (name) {
    case "ui_open_panel":
      openPanel(args.title || "Painel", args.content || "");
      toast(`Painel aberto: ${args.title}`, "ok");
      break;
    case "ui_close_panels":
      closeAllPanels();
      toast("Painéis fechados.");
      break;
    case "ui_show_text":
      showHudText(args.text || "");
      break;
    default:
      toast(`Ferramenta não implementada na interface: ${name}`, "warn");
  }
}

/* ---------- microfone + barge-in simples ---------- */
async function toggleMic() {
  if (!S.micOn) {
    if (!S.ws || S.ws.readyState !== WebSocket.OPEN) {
      toast("Conecte-se ao backend antes de falar.", "warn");
      return;
    }
    try {
      S.mic = S.mic || new Microphone(onMicBlock, onMicLevel);
      await S.mic.start();
    } catch (err) {
      toast(`Autorização do microfone negada: ${err.message}`, "err", 6000);
      S.mic = null;
      return;
    }
    S.micOn = true;
    $("btn-mic").classList.add("on");
    setStatus("listen");
    addMsg("sys", "Microfone ligado (aprovado por você).");
  } else {
    S.mic.stop();
    S.micOn = false;
    $("btn-mic").classList.remove("on");
    setStatus("ready");
    addMsg("sys", "Microfone desligado.");
  }
}

function onMicBlock({ bytes }) {
  if (S.ws && S.ws.readyState === WebSocket.OPEN) S.ws.send(bytes);
}

let hiFrames = 0, bargeCooldown = 0;
function onMicLevel(level) {
  S.core.setLevel(level);
  // Barge-in best-effort: fala local alta enquanto a Cyborgue responde.
  const now = performance.now();
  const speaking = S.player.busy || S.status === "speak";
  if (speaking && level > 0.18) hiFrames++; else hiFrames = 0;
  if (speaking && hiFrames >= 4 && now > bargeCooldown) {
    bargeCooldown = now + 2500;
    interrupt();
  }
}

function interrupt() {
  S.player.abort();
  if (S.ws && S.ws.readyState === WebSocket.OPEN) {
    S.ws.send(JSON.stringify({ type: "interrupt" }));
  }
  setStatus(S.micOn ? "listen" : "ready");
}

/* ---------- mensagens digitadas ---------- */
function sendText(text) {
  text = text.trim();
  if (!text) return;
  if (!S.ws || S.ws.readyState !== WebSocket.OPEN) {
    toast("Sem conexão — modo demonstração, nada foi enviado.", "warn");
    return;
  }
  addMsg("user", text);
  S.ws.send(JSON.stringify({ type: "text", text }));
}

/* ---------- configuração ---------- */
function openConfig() {
  $("cfg-endpoint").value = backendEndpoint();
  $("cfg-token").value = localStorage.getItem(LS_TOKEN) || "";
  $("config-dialog").showModal();
}

function saveConfig() {
  const ep = $("cfg-endpoint").value.trim().replace(/\/+$/, "");
  const tk = $("cfg-token").value.trim();
  if (ep) localStorage.setItem(LS_ENDPOINT, ep);
  if (tk) localStorage.setItem(LS_TOKEN, tk);
  $("config-dialog").close();
  S.reconnects = 0;
  connect();
}

/* ---------- eventos da interface ---------- */
$("btn-config").addEventListener("click", openConfig);
$("cfg-save").addEventListener("click", saveConfig);
$("cfg-cancel").addEventListener("click", () => $("config-dialog").close());
$("btn-mic").addEventListener("click", toggleMic);
$("chat-form").addEventListener("submit", (ev) => {
  ev.preventDefault();
  sendText($("chat-input").value);
  $("chat-input").value = "";
});
$("chat-clear").addEventListener("click", () => { $("chat-log").innerHTML = ""; });

const soundBtn = $("btn-sound");
soundBtn.addEventListener("click", () => {
  const muted = soundBtn.classList.toggle("off");
  S.player.setMuted(muted);
});

// Ao voltar para a aba, reconecta se a sessão caiu.
document.addEventListener("visibilitychange", () => {
  if (!document.hidden && !S.ws && localStorage.getItem(LS_TOKEN)) connect();
});

/* ---------- partida ---------- */
setStatus("demo");
addMsg("sys", "Cyborgue web iniciada. Sem conexão: modo demonstração.");
connect();
