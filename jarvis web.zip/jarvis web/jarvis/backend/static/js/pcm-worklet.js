/**
 * AudioWorklet: coleta áudio do microfone e agrupa em blocos ~64 ms.
 * Envia { samples: Float32Array, level: number } para o thread principal.
 */
class PCMFeeder extends AudioWorkletProcessor {
  constructor() {
    super();
    this._buf = new Float32Array(1024);
    this._i = 0;
  }

  process(inputs) {
    const ch = inputs[0] && inputs[0][0];
    if (!ch) return true;

    let n = ch.length;
    let need = Math.min(n, this._buf.length - this._i);
    this._buf.set(ch.subarray(0, need), this._i);
    this._i += need;
    ch.copyWithin(0, need);
    n -= need;

    if (this._i >= this._buf.length) {
      let sum = 0;
      for (let k = 0; k < this._buf.length; k++) sum += this._buf[k] * this._buf[k];
      const rms = Math.sqrt(sum / this._buf.length);
      this.port.postMessage(
        { samples: this._buf.slice(0), level: rms },
      );
      this._i = 0;

      if (n > 0) { // resto que não coube (raro)
        this._buf.set(ch.subarray(0, Math.min(n, this._buf.length)), 0);
        this._i = Math.min(n, this._buf.length);
      }
    }
    return true;
  }
}

registerProcessor("pcm-feeder", PCMFeeder);
