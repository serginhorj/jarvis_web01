/**
 * Núcleo visual da Cyborgue: anéis ciano reativos desenhados em canvas.
 * Reage ao modo (idle/ouvindo/falando) e ao nível do microfone.
 */

const TAU = Math.PI * 2;

export function createCore(canvas) {
  const ctx = canvas.getContext("2d");
  const state = {
    mode: "idle",     // idle | listening | speaking | error
    level: 0,         // RMS do mic (0..1)
    pulse: 0,         // energia da fala recebida (0..1)
  };

  function resize() {
    const dpr = window.devicePixelRatio || 1;
    const r = canvas.parentElement.getBoundingClientRect();
    canvas.width = r.width * dpr;
    canvas.height = r.height * dpr;
  }
  window.addEventListener("resize", resize);
  resize();

  let t = 0;
  (function frame() {
    t += 0.016;
    const W = canvas.width, H = canvas.height;
    const cx = W / 2, cy = H / 2;
    const base = Math.min(W, H);
    ctx.clearRect(0, 0, W, H);

    const energy =
      state.mode === "speaking" ? 0.55 + state.pulse * 0.5
      : state.mode === "listening" ? 0.45 + state.level * 2.2
      : state.mode === "error" ? 0.3
      : 0.35;

    const cyan = state.mode === "error" ? "255,84,112"
               : state.mode === "listening" ? "0,217,255" : "0,180,230";

    // brilho central
    const glow = ctx.createRadialGradient(cx, cy, 0, cx, cy, base * 0.28 * (0.9 + energy * 0.25));
    glow.addColorStop(0, `rgba(${cyan},${0.30 + energy * 0.25})`);
    glow.addColorStop(0.5, `rgba(${cyan},0.08)`);
    glow.addColorStop(1, "rgba(0,0,0,0)");
    ctx.fillStyle = glow;
    ctx.fillRect(0, 0, W, H);

    // anéis
    drawRing(cx, cy, base * 0.30, 2.2, `rgba(${cyan},${0.55})`, t * 0.6, 5, energy);
    drawRing(cx, cy, base * 0.245, 1.4, `rgba(${cyan},${0.35 + energy * 0.2})`, -t * 0.9, 3, energy);
    drawRing(cx, cy, base * 0.19, 3.0, `rgba(${cyan},${0.8})`, t * 0.45, 2, energy, true);

    // ondas de voz (só quando falando/ouvindo com sinal)
    if (energy > 0.5) {
      const r0 = base * 0.33;
      for (let i = 0; i < 3; i++) {
        const pr = r0 + ((t * 0.7 + i * 0.33) % 1) * base * 0.16;
        ctx.beginPath();
        ctx.arc(cx, cy, pr, 0, TAU);
        ctx.strokeStyle = `rgba(${cyan},${(0.25 * (1 - (pr - r0) / (base * 0.16)))})`;
        ctx.lineWidth = 2;
        ctx.stroke();
      }
    }

    requestAnimationFrame(frame);
  })();

  function drawRing(cx, cy, r, lw, color, rot, segs, energy, dashed) {
    const base = Math.min(canvas.width, canvas.height);
    ctx.save();
    ctx.translate(cx, cy);
    ctx.rotate(rot);
    ctx.beginPath();
    ctx.arc(0, 0, r, 0, TAU);
    ctx.strokeStyle = color;
    ctx.lineWidth = lw * (window.devicePixelRatio || 1);
    if (dashed) {
      ctx.setLineDash([base * 0.02, base * 0.05]);
    } else {
      // arcos intercalados
      const gap = TAU / segs * 0.18;
      ctx.setLineDash([TAU / segs - gap, gap]);
    }
    ctx.shadowColor = color;
    ctx.shadowBlur = 12 + energy * 18;
    ctx.stroke();
    ctx.restore();
  }

  return {
    setMode(m) { state.mode = m; },
    setLevel(v) { state.level = v; },
    /** chamado a cada bloco de áudio recebido para pulsar com a voz */
    speakPulse() {
      state.pulse = Math.min(1, state.pulse + 0.18);
      setTimeout(() => { state.pulse *= 0.5; }, 90);
    },
  };
}
