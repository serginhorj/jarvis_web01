/**
 * Módulos de áudio da Cyborgue:
 *  - Microfone (AudioWorklet → PCM16 mono 16 kHz para o backend)
 *  - Reprodução (PCM16 24 kHz recebido do backend → fila de buffers)
 */

const MIC_RATE = 16000;   // exigido pela Gemini Live API
const AUDIO_RATE = 24000; // taxa do áudio de resposta

/** Conversão Float32 → Int16 (PCM16 little-endian). */
export function floatTo16(bytes) {
  const out = new Int16Array(bytes.length);
  for (let i = 0; i < bytes.length; i++) {
    const s = Math.max(-1, Math.min(1, bytes[i]));
    out[i] = s < 0 ? s * 0x8000 : s * 0x7fff;
  }
  return out;
}

/* ------------------------------------------------------------
   Microfone
   ------------------------------------------------------------ */
export class Microphone {
  constructor(onBlock, onLevel) {
    this.onBlock = onBlock;   // ({ bytes: ArrayBuffer }) por bloco
    this.onLevel = onLevel;   // (rms 0..1) para visualização / barge-in
    this._ctx = null;
    this._node = null;
    this._stream = null;
    this._rest = null;        // amostras sobras (re-amostragem simples)
  }

  get active() { return !!this._stream; }

  /** Pede autorização e inicia a coleta. */
  async start() {
    if (this.active) return;
    this._stream = await navigator.mediaDevices.getUserMedia({
      audio: {
        channelCount: 1,
        echoCancellation: true,
        noiseSuppression: true,
        autoGainControl: true,
      },
    });

    let ctx;
    try {
      ctx = new AudioContext({ sampleRate: MIC_RATE });
    } catch {
      ctx = new AudioContext(); // Safari antigo — re-amostramos manualmente
    }
    this._ctx = ctx;
    await ctx.audioWorklet.addModule("/js/pcm-worklet.js");
    this._node = new AudioWorkletNode(ctx, "pcm-feeder");

    let lastLevel = 0;
    this._node.port.onmessage = (ev) => {
      const { samples, level } = ev.data;
      lastLevel = level;
      this.onLevel && this.onLevel(level);

      // Se o contexto realmente estiver a 16 kHz, envia direto.
      if (ctx.sampleRate === MIC_RATE) {
        this._emit(samples);
      } else {
        // Re-amostragem linear simples (fallback, qualidade reduzida)
        const ratio = ctx.sampleRate / MIC_RATE;
        const src = this._rest
          ? Float32Concat(this._rest, samples)
          : samples;
        const out = new Float32Array(Math.floor(src.length / ratio));
        for (let i = 0; i < out.length; i++) {
          const x = i * ratio;
          const i0 = Math.floor(x);
          const f = x - i0;
          const a = src[i0] || 0;
          const b = src[i0 + 1] || a;
          out[i] = a + (b - a) * f;
        }
        const consume = Math.floor(out.length * ratio);
        this._rest = src.slice(consume);
        if (out.length > 0) this._emit(out);
      }
    };

    const src = ctx.createMediaStreamSource(this._stream);
    src.connect(this._node);
    // _node não é ligado ao destino de saída: o microfone não ecoa no alto-falante.
  }

  _emit(f32) {
    const pcm = floatTo16(f32);
    this.onBlock({ bytes: pcm.buffer, rate: MIC_RATE });
  }

  stop() {
    if (this._stream) {
      for (const t of this._stream.getTracks()) t.stop();
      this._stream = null;
    }
    if (this._node) { this._node.port.onmessage = null; this._node = null; }
    if (this._ctx) { this._ctx.close().catch(() => {}); this._ctx = null; }
    this._rest = null;
  }
}

function Float32Concat(a, b) {
  const out = new Float32Array(a.length + b.length);
  out.set(a, 0);
  out.set(b, a.length);
  return out;
}

/* ------------------------------------------------------------
   Reprodução da resposta (PCM16 24 kHz, fila contínua)
   ------------------------------------------------------------ */
export class Player {
  constructor() {
    this._ctx = null;
    this._gain = null;
    this._sources = new Set();
    this._nextTime = 0;
    this._muted = false;
  }

  _ensure() {
    if (!this._ctx) {
      this._ctx = new AudioContext({ sampleRate: AUDIO_RATE });
      this._gain = this._ctx.createGain();
      this._gain.connect(this._ctx.destination);
      this._gain.gain.value = this._muted ? 0 : 1;
    }
    return this._ctx;
  }

  setMuted(m) {
    this._muted = m;
    if (this._gain) {
      this._gain.gain.setTargetAtTime(m ? 0 : 1, this._ctx.currentTime, 0.02);
    }
  }

  /** Adiciona um bloco PCM16 recebido do backend (24 kHz). */
  enqueue(bytes) {
    const ctx = this._ensure();
    const int16 = new Int16Array(bytes);
    const f32 = new Float32Array(int16.length);
    for (let i = 0; i < int16.length; i++) f32[i] = int16[i] / 32768;

    const buf = ctx.createBuffer(1, f32.length, AUDIO_RATE);
    buf.copyToChannel(f32, 0);

    const src = ctx.createBufferSource();
    src.buffer = buf;
    src.connect(this._gain);

    const when = Math.max(ctx.currentTime + 0.06, this._nextTime);
    src.start(when);
    this._nextTime = when + buf.duration;
    this._sources.add(src);
    src.onended = () => this._sources.delete(src);
  }

  /** Corta imediatamente tudo que está tocando (interrupção/barge-in). */
  abort() {
    for (const s of this._sources) {
      try { s.stop(); } catch { /* já parado */ }
    }
    this._sources.clear();
    this._nextTime = 0;
  }

  /** Há algo ainda programado/tocando? */
  get busy() {
    if (!this._ctx || this._sources.size === 0) return false;
    return this._nextTime > this._ctx.currentTime - 0.05;
  }

  close() {
    this.abort();
    if (this._ctx) this._ctx.close().catch(() => {});
    this._ctx = null;
  }
}
