"""
J.A.R.V.I.S. - ponte FastAPI <-> Gemini Live API.

Browser (WS /ws) <-> FastAPI <-> Gemini Live (client.aio.live.connect)

Binário no WS do navegador: PCM16 mono 16 kHz (mic) e 24 kHz (resposta).
JSON no WS do navegador: transcript / tool_call / turn_complete /
interrupted / error / ready / tool_used.
"""
import asyncio
import json
import os
import time
from contextlib import asynccontextmanager
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

from fastapi import FastAPI, Query, WebSocket, WebSocketDisconnect
from fastapi.staticfiles import StaticFiles

from google import genai
from google.genai import types

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------
GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY", "")
GEMINI_MODEL = os.environ.get("GEMINI_MODEL", "gemini-3.8-live")
GEMINI_VOICE = os.environ.get("GEMINI_VOICE", "Charon")
GEMINI_SEARCH = os.environ.get("GEMINI_SEARCH", "0").strip() == "1"
APP_TOKEN = os.environ.get("APP_TOKEN", "")
USER_NAME = os.environ.get("USER_NAME", "Raphael")
DATA_DIR = Path(os.environ.get("DATA_DIR", "./data"))
STATIC_DIR = Path(os.environ.get("STATIC_DIR", "./static"))

TZ = ZoneInfo("America/Sao_Paulo")

SYSTEM_PROMPT = f"""Você é J.A.R.V.I.S., o assistente pessoal de {USER_NAME}.
Fale sempre em português do Brasil. Trate o usuário sempre como "senhor"
(ocasionalmente "Raphael, senhor", se soar natural). Tom: calmo, competente e
levemente irônico — como um mordomo britânico digital. Gere respostas CURTAS
(1 a 2 frases na fala), a menos que peçam detalhes, listas ou relatórios.
Use sempre a ferramenta time_now para perguntas de data/hora — nunca tente
adivinhar a hora. Quando o senhor pedir para anotar ou lembrar algo, use
memory_remember / memory_recall. Quando o senhor pedir para abrir um painel,
mostrar texto na tela ou algo visual, use ui_open_panel / ui_show_text /
ui_close_panels. Ao usar uma ferramenta, aja como quem aciona um sistema da
casa."""

FDecl = types.FunctionDeclaration
FSch = types.Schema
TOOL_DECLARATIONS = types.Tool(function_declarations=[
    FDecl(name="time_now",
          description="Retorna data e hora atuais do servidor (fuso de São Paulo).",
          parameters=FSch(type="OBJECT", properties={})),
    FDecl(name="memory_remember",
          description="Guarda uma informação permanente na memória do Jarvis.",
          parameters=FSch(type="OBJECT",
                          properties={
                              "key": FSch(type="STRING",
                                          description="Identificador curto, ex.: 'aniversario'."),
                              "value": FSch(type="STRING",
                                            description="O que memorizar."),
                          },
                          required=["key", "value"])),
    FDecl(name="memory_recall",
          description="Recupera uma informação guardada na memória do Jarvis.",
          parameters=FSch(type="OBJECT",
                          properties={
                              "key": FSch(type="STRING",
                                          description="Identificador que foi memorizado."),
                          },
                          required=["key"])),
    FDecl(name="ui_open_panel",
          description="Abre um painel flutuante na tela do usuário.",
          parameters=FSch(type="OBJECT",
                          properties={
                              "title": FSch(type="STRING", description="Título do painel."),
                              "content": FSch(type="STRING", description="Conteúdo em texto."),
                          },
                          required=["title", "content"])),
    FDecl(name="ui_close_panels",
          description="Fecha todos os painéis abertos na tela do usuário.",
          parameters=FSch(type="OBJECT", properties={})),
    FDecl(name="ui_show_text",
          description="Mostra um texto em destaque no HUD do usuário.",
          parameters=FSch(type="OBJECT",
                          properties={
                              "text": FSch(type="STRING", description="Texto a exibir."),
                          },
                          required=["text"])),
])


def build_search_tool() -> types.Tool | None:
    """Google Search grounding só se GEMINI_SEARCH=1 (cota no plano gratuito)."""
    if not GEMINI_SEARCH:
        return None
    try:
        return types.Tool(google_search=types.GoogleSearch())
    except Exception:
        return types.Tool(google_search={})


def build_live_config() -> types.LiveConnectConfig:
    tools = [TOOL_DECLARATIONS]
    st = build_search_tool()
    if st is not None:
        tools.append(st)
    return types.LiveConnectConfig(
        response_modalities=["AUDIO"],
        system_instruction=types.Content(
            role="system",
            parts=[types.Part(text=SYSTEM_PROMPT)],
        ),
        speech_config=types.SpeechConfig(
            voice_config=types.VoiceConfig(
                prebuilt_voice_config=types.PrebuiltVoiceConfig(
                    voice_name=GEMINI_VOICE,
                ),
            ),
        ),
        input_audio_transcription=types.AudioTranscriptionConfig(),
        output_audio_transcription=types.AudioTranscriptionConfig(),
        tools=tools,
        temperature=1.0,
    )


# ---------------------------------------------------------------------------
# Memória (volume /data)
# ---------------------------------------------------------------------------
memory_lock: asyncio.Lock | None = None


def _memory_file() -> Path:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    return DATA_DIR / "memory.json"


def _memory_read() -> dict:
    f = _memory_file()
    if not f.exists():
        return {}
    try:
        return json.loads(f.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _memory_write(data: dict) -> None:
    f = _memory_file()
    tmp = f.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(f)


async def tool_time_now(_args: dict | None = None) -> dict:
    now = datetime.now(TZ)
    weekdays = ["segunda", "terça", "quarta", "quinta", "sexta", "sábado", "domingo"]
    return {
        "ok": True,
        "iso": now.isoformat(),
        "weekday": weekdays[now.weekday()],
        "date": now.strftime("%d/%m/%Y"),
        "time": now.strftime("%H:%M"),
    }


async def tool_memory_remember(args: dict) -> dict:
    key = str(args.get("key", "")).strip().lower()
    value = str(args.get("value", "")).strip()
    if not key or not value:
        return {"ok": False, "error": "key e value são obrigatórios"}
    data = _memory_read()
    data[key] = {"value": value, "saved_at": datetime.now(TZ).isoformat()}
    _memory_write(data)
    return {"ok": True, "stored": key}


async def tool_memory_recall(args: dict) -> dict:
    key = str(args.get("key", "")).strip().lower()
    data = _memory_read()
    entry = data.get(key)
    if entry is None:
        out: dict = {"ok": False, "error": f"nada memorizado sobre '{key}'"}
        if data:
            out["known_keys"] = sorted(data.keys())
        return out
    return {"ok": True, "key": key, "value": entry.get("value"),
            "saved_at": entry.get("saved_at")}


TOOLS_SERVER = {
    "time_now": tool_time_now,
    "memory_remember": tool_memory_remember,
    "memory_recall": tool_memory_recall,
}
TOOLS_UI = {"ui_open_panel", "ui_close_panels", "ui_show_text"}


async def run_tool(name: str, args: dict, ws: WebSocket) -> dict:
    if name in TOOLS_UI:
        await ws.send_json({"type": "tool_call", "name": name, "args": args,
                            "ts": int(time.time() * 1000)})
        return {"ok": True, "dispatched": name}
    fn = TOOLS_SERVER.get(name)
    if fn is None:
        return {"ok": False, "error": f"função desconhecida: {name}"}
    try:
        return await fn(args)
    except Exception as exc:  # pragma: no cover
        return {"ok": False, "error": str(exc)}


# ---------------------------------------------------------------------------
# Erros amigáveis
# ---------------------------------------------------------------------------
def friendly_error(exc: Exception) -> str:
    msg = str(exc)
    low = msg.lower()
    if "429" in msg or "resource_exhausted" in low or "quota" in low:
        return ("Créditos do Gemini esgotados por agora, senhor. "
                "A cotação grátis recarrega por minuto/dia — tente de novo em instantes.")
    if "api key" in low or ("invalid" in low and "key" in low):
        return "A chave do Gemini foi recusada. Vejamos o .env, senhor."
    if "permission" in low or "403" in msg:
        return "Acesso negado pelo Gemini. A chave não tem permissão para esse modelo."
    return f"Falha na ponte com o Gemini: {msg[:240]}"


# ---------------------------------------------------------------------------
# Lifespan + app
# ---------------------------------------------------------------------------
@asynccontextmanager
async def lifespan(app: FastAPI):
    global memory_lock
    memory_lock = asyncio.Lock()
    if not GEMINI_API_KEY:
        print("[jarvis] AVISO: GEMINI_API_KEY não configurada")
    else:
        print(f"[jarvis] Gemini Live: model={GEMINI_MODEL} voice={GEMINI_VOICE} "
              f"search={'on' if GEMINI_SEARCH else 'off'}")
    yield


app = FastAPI(title="JARVIS", lifespan=lifespan)


@app.get("/healthz")
async def healthz():
    return {"status": "ok", "model": GEMINI_MODEL,
            "voice": GEMINI_VOICE, "user": USER_NAME}


# ---------------------------------------------------------------------------
# WebSocket <-> Gemini Live
# ---------------------------------------------------------------------------
def _pcm_blob(data: bytes, rate: int) -> types.Blob:
    return types.Blob(data=data, mime_type=f"audio/pcm;rate={rate}")


async def pump_browser_to_gemini(ws: WebSocket, session, gem_queue: asyncio.Queue):
    """Recebe do navegador e despacha para a Live API."""
    while True:
        msg = await ws.receive()
        if msg["type"] == "websocket.disconnect":
            break
        data = msg.get("bytes")
        text = msg.get("text")
        if data:
            gem_queue.put_nowait(("audio", data))
            continue
        if text:
            try:
                env = json.loads(text)
            except Exception:
                continue
            kind = env.get("type", "")
            if kind == "text":
                gem_queue.put_nowait(("text", env.get("text", "")))
            elif kind == "interrupt":
                gem_queue.put_nowait(("signal", "interrupt"))
            # "pong" e outros são ignorados


async def gemini_feeder(session, gem_queue: asyncio.Queue):
    """Consome a fila do navegador e envia para a sessão Gemini."""
    while True:
        kind, payload = await gem_queue.get()
        if kind == "audio":
            await session.send_realtime_input(media=_pcm_blob(payload, 16000))
        elif kind == "text":
            await session.send_client_content(
                turns=[types.Content(role="user",
                                     parts=[types.Part(text=payload)])],
            )
        elif kind == "signal" and payload == "interrupt":
            try:
                await session.send_realtime_input(audio_stream_end=True)
            except Exception:
                pass


async def pump_from_gemini(session, ws: WebSocket):
    """Recebe da Live API e empurra ao navegador.

    session.receive() encerra o async-for a cada turn_complete; por isso o
    loop externo while True."""
    while True:
        got_turn = False
        try:
            async for resp in session.receive():
                if resp.tool_call and resp.tool_call.function_calls:
                    fcs = resp.tool_call.function_calls
                    try:
                        await ws.send_json({"type": "tool_used",
                                            "names": [fc.name for fc in fcs]})
                    except WebSocketDisconnect:
                        raise
                    except Exception:
                        pass
                    responses = []
                    for fc in fcs:
                        args = dict(fc.args or {})
                        result = await run_tool(fc.name, args, ws)
                        responses.append(types.FunctionResponse(
                            id=fc.id, name=fc.name, response=result))
                    await session.send_tool_response(function_responses=responses)
                    continue

                sc = resp.server_content
                if not sc:
                    continue

                if sc.input_transcription and sc.input_transcription.text:
                    await ws.send_json({"type": "transcript", "role": "user",
                                        "text": sc.input_transcription.text})
                if sc.output_transcription and sc.output_transcription.text:
                    await ws.send_json({"type": "transcript", "role": "jarvis",
                                        "text": sc.output_transcription.text})
                if sc.interrupted:
                    await ws.send_json({"type": "interrupted"})

                turn = sc.model_turn
                if turn and turn.parts:
                    for part in turn.parts:
                        inline = getattr(part, "inline_data", None)
                        if inline and inline.data and "audio" in (inline.mime_type or ""):
                            await ws.send_bytes(inline.data)

                if sc.turn_complete:
                    await ws.send_json({"type": "turn_complete"})
                    got_turn = True
                    break
        except WebSocketDisconnect:
            raise
        except Exception as exc:
            try:
                await ws.send_json({"type": "error", "message": friendly_error(exc)})
            except Exception:
                pass
            return

        if not got_turn:
            break  # stream da sessão fechou


@app.websocket("/ws")
async def ws_endpoint(ws: WebSocket, token: str = Query("")):
    if not APP_TOKEN or token != APP_TOKEN:
        await ws.close(code=4401, reason="invalid token")
        return
    await ws.accept()
    gem_queue: asyncio.Queue = asyncio.Queue()
    client = genai.Client(api_key=GEMINI_API_KEY)
    try:
        async with client.aio.live.connect(
                model=GEMINI_MODEL, config=build_live_config()) as session:
            await ws.send_json({"type": "ready", "model": GEMINI_MODEL,
                                "voice": GEMINI_VOICE, "user": USER_NAME})
            t1 = asyncio.create_task(pump_browser_to_gemini(ws, session, gem_queue))
            t2 = asyncio.create_task(gemini_feeder(session, gem_queue))
            t3 = asyncio.create_task(pump_from_gemini(session, ws))
            done, pending = await asyncio.wait(
                {t1, t2, t3}, return_when=asyncio.FIRST_COMPLETED)
            for t in pending:
                t.cancel()
            for t in done:
                exc = t.exception()
                if exc and not isinstance(exc, WebSocketDisconnect):
                    print(f"[jarvis] pump exception: {exc!r}")
    except Exception as exc:
        print(f"[jarvis] session error: {exc!r}")
        try:
            await ws.send_json({"type": "error", "message": friendly_error(exc)})
            await ws.close(code=1011)
        except Exception:
            pass
        return
    try:
        await ws.close()
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Frontend estático
# ---------------------------------------------------------------------------
if (STATIC_DIR / "index.html").exists():
    app.mount("/", StaticFiles(directory=str(STATIC_DIR), html=True), name="static")
else:
    print(f"[jarvis] AVISO: {STATIC_DIR}/index.html não encontrado; "
          "montagem estática adiada")
